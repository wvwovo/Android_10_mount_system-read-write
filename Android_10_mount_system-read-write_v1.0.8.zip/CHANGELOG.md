# 更新日志

## 1.0.8
- setting.txt新增三个可选项。
```
  set_flash是否要刷入。
  skip_build_s_config不生成合成super需要用的s_config.txt。
  不提取super直接刷入自定义的super。
```

## 1.0.7
- 修复判断可扩容多大数量错误的问题

## 1.0.6
- 增加可选择是否解锁super分区选项
- 增加一个确认setting.txt版本功能，减少用错版本导致出错
  
## 1.0.5
- 增加还原功能,现在不会主动删提取的super_stock.bin文件(beta)
- 如果出现还原失败，可能需要手动复制super_stock.bin，然后自己手动用linux dd命令或adb fastboot刷回去
- 目前无法显示过程进度，所以怎么卡死的都不知道

## 1.0.4
- 尝试支持vab分区
- 尝试加一个弱的检查配置文件功能，当配置文件里写的分区数量不等于检查到的img文件数量则不刷入

## 1.0.3
- 尝试支持选择扩大指定分区
